<?php

// src/Shop/UserBundle/ShopUserBundle.php

namespace Shop\UserBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ShopUserBundle extends Bundle {
    
}
