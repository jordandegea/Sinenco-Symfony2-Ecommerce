$(document).ready(function(){  
    $("#topMenuCartLink").on("click", function(){ $("#topMenuCartModal").modal();});
});