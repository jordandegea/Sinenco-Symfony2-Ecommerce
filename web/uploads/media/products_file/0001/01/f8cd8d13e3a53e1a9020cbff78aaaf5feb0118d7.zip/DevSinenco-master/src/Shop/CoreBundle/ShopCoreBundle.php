<?php

namespace Shop\CoreBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ShopCoreBundle extends Bundle {
    
}
