<?php

namespace Services\CoreBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ServicesCoreBundle extends Bundle
{
}
