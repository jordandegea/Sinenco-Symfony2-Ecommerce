<?php

namespace Shop\PaymentBundle\Events;


final class InvoiceCoreEvents

{

  const onInvoiceComplete = 'shop.invoiceevent.complete';


}