<?php

namespace Shop\ProductBundle\Admin;

use Sonata\AdminBundle\Admin\Admin;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Form\FormMapper;

class ProductAdmin extends Admin {

    // Fields to be shown on create/edit forms
    protected function configureFormFields(FormMapper $formMapper) {

        $formMapper
                ->with('Defaults', array('tab' => true))
                ->add('image', 'sonata_type_model_list', array(), array(
                    'link_parameters' => array('context' => 'products')
                ))
                ->add('canonicalName')
                ->add(
                        'category', 'entity', array(
                    'class' => 'Shop\ProductBundle\Entity\Category'
                        )
                )
                ->setHelps(array(
                    'canonicalName' => 'pattern : /^[a-z0-9\-]+$/',
                ))
                ->end()
                ->end()
                ->with('Languages', array('tab' => true))
                ->add('translations', 'a2lix_translations')
                ->end()
                ->end()
                ->with('Prices', array('tab' => true))
                ->add('prices', 'sonata_type_collection', array(
                    'label' => 'Prices',
                    'by_reference' => false
                        ), array(
                    'edit' => 'inline',
                    'inline' => 'table',
                    'sortable' => 'position',
                    'targetEntity' => 'Shop\ProductBundle\Entity\Prices',
                        )
                )
                ->setHelps(array(
                    'prices' => 'One line per currency. ',
                ))
                ->end()
                ->end()
                ->with('Options', array('tab' => true))
                ->add('options', 'sonata_type_model', array(
                    'multiple' => true,
                    'by_reference' => false,
                    'required' => false
                        )
                )
                ->end()
                ->end()

        ;
    }

    // Fields to be shown on filter forms
    protected function configureDatagridFilters(DatagridMapper $datagridMapper) {
        $datagridMapper
                ->add('canonicalName')
                ->add('prices')

        ;
    }

    // Fields to be shown on lists
    protected function configureListFields(ListMapper $listMapper) {
        $listMapper
                ->addIdentifier('canonicalName')
                ->add('_action', 'actions', [
                    'actions' => [
                        'show' => [],
                        'edit' => [],
                        'delete' => [],
                    ]
                        ]
                )
        ;
    }

}
