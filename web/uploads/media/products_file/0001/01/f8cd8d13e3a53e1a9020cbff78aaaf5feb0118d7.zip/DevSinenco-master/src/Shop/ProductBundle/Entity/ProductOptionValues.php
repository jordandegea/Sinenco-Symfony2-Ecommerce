<?php

namespace Shop\ProductBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Knp\DoctrineBehaviors\Model as ORMBehaviors;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * ProductOptionValues
 *
 * @ORM\Table()
 * @ORM\Entity
 */
class ProductOptionValues {

    
    use ORMBehaviors\Translatable\Translatable;
    
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @ORM\Column(name="canonical_name", type="string", length=255, unique=true)
     * @Assert\Regex("/^[a-z0-9\-]+$/")
     * @Assert\Length(min=2)
     */
    private $canonicalName;

    /**
     *
     * Attention, ici c'est un OneToMany associé à un ManyToMany pour eviter d'avoir 
     * une relation bidirectionnelle.
     * 
     * @ORM\ManyToMany(targetEntity="Shop\ProductBundle\Entity\Prices", cascade={"persist"})
     * @ORM\JoinTable(name="productoptionvalues_prices",
     *      joinColumns={@ORM\JoinColumn(name="productoptionvalues_id", referencedColumnName="id")},
     *      inverseJoinColumns={@ORM\JoinColumn(name="prices_id", referencedColumnName="id", unique=true)}
     *      )
     * 
     */
    private $prices;

    public function __toString() {
        return $this->canonicalName;
    }

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId() {
        return $this->id;
    }

    /**
     * Constructor
     */
    public function __construct() {
        $this->prices = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Set canonicalName
     *
     * @param string $canonicalName
     * @return Product
     */
    public function setCanonicalName($canonicalName) {
        $this->canonicalName = $canonicalName;

        return $this;
    }

    /**
     * Get canonicalName
     *
     * @return string 
     */
    public function getCanonicalName() {
        return $this->canonicalName;
    }

    /**
     * Add prices
     *
     * @param \Shop\ProductBundle\Entity\Prices $prices
     * @return ProductOptionValues
     */
    public function addPrice(\Shop\ProductBundle\Entity\Prices $prices) {
        $this->prices[] = $prices;

        return $this;
    }

    /**
     * Remove prices
     *
     * @param \Shop\ProductBundle\Entity\Prices $prices
     */
    public function removePrice(\Shop\ProductBundle\Entity\Prices $prices) {
        $this->prices->removeElement($prices);
    }

    /**
     * Get prices
     *
     * @return \Doctrine\Common\Collections\Collection 
     */
    public function getPrices() {
        return $this->prices;
    }

}
