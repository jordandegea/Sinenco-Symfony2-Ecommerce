<?php

namespace Shop\ProductBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ShopProductBundle extends Bundle {
    
}
