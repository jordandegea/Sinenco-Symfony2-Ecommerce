Sinenco development repository
========================

That is the personnal repository of Sinenco of Jordan DE GEA

Important : 
----
There is an important parameters in app/parameters.yml named web_dir. 
When you install Sinenco, edit this parameter. 

First Installation. 
ln ...php.ini /etc/php.ini
php app/console doctrine:database:create
php app/console doctrine:schema:create

Application to be installed : 
http://wkhtmltopdf.org/downloads.html 
for html2Pdf conversion

Usefull command :
---- 
php app/console assets:install web/
php app/console assetic:dump --env=prod