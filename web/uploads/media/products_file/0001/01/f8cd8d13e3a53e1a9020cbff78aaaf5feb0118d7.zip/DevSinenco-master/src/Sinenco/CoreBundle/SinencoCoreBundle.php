<?php

namespace Sinenco\CoreBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SinencoCoreBundle extends Bundle {
    
}
