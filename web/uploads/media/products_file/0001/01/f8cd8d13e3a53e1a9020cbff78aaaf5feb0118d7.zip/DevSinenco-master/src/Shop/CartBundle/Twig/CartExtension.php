<?php

namespace Shop\CartBundle\Twig;

use Shop\CartBundle\Entity\CartItem,
 Shop\ProductBundle\Twig\ProductExtension,
 Shop\CoreBundle\Services\Currency;

class CartExtension extends \Twig_Extension {

    private $container;
    private $service;
    
    public function __construct($container) {
        $this->container = $container;
        $this->service = $container->get("shop_cart.cart");
        $this->serviceProduct = $container->get("shop_products");
    }
    
    public function getFilters() {
        return array(
            new \Twig_SimpleFilter('findRowOnArrayWithCanonicalName', array($this, 'findRowOnArrayWithCanonicalName')),
        );
    }

    public function getFunctions() {
        return array(
            new \Twig_SimpleFunction('CartItemGetFormattedFieldPrice', array($this, 'CartItemGetFormattedFieldPrice'), array('is_safe' => array('html'))),
        );
    }

    public function findRowOnArrayWithCanonicalName($array, $canonicalName) {
        foreach ($array as $row) {
            if (method_exists($row, 'getCanonicalName') && $row->getCanonicalName() == $canonicalName) {
                return $row;
            }
        }
        return null;
    }

    public function CartItemGetFormattedFieldPrice( $field, $cartItem, $currencyOrQuantity = null, $currency = null) {
        
        $product = $cartItem->children["product"];
        
        $productObject = $product->vars["value"];
        
        $prices = $productObject->getPrices() ;
        
        if ($currencyOrQuantity == null) {
            $currency = $this->serviceProduct->getCurrencyIfNotDefined($currency);
            $quantity = 1;
        } else {
            if (is_numeric($currencyOrQuantity)) {
                $currency = $this->serviceProduct->getCurrencyIfNotDefined($currency);
                $quantity = $currencyOrQuantity;
            } else {
                $currency = $currencyOrQuantity;
                $quantity = 1;
            }
        }


        $method = 'get' . ucfirst($field);

        $price = $this->serviceProduct->getAssociatedPriceOfCurrency($prices, $currency);

        if ($price != null && method_exists($price, $method)) {
            return $this->serviceProduct->getFormattedPrice($price->getCurrency(), $quantity * $price->$method());
        }

        return '';
    }
    
    
    public function getName() {
        return 'shop_cart_cartextension';
    }

}
