<?php

namespace Shop\CartBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ShopCartBundle extends Bundle {
    
}
