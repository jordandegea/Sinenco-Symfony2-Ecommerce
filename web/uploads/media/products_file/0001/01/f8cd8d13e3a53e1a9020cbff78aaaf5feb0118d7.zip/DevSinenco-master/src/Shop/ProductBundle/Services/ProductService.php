<?php

namespace Shop\ProductBundle\Services;

use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Cookie;
use Symfony\Component\HttpKernel\Event\FilterResponseEvent;
use Doctrine\ORM\EntityManager;
use Symfony\Component\DependencyInjection\Container;
use Symfony\Component\HttpKernel\Event\GetResponseEvent,
    Shop\CoreBundle\Entity\Currencies;

class ProductService {

    protected $container;
    protected $response;
    protected $em;

    /* Return the currency choosen
     * @return string
     */

    public function onKernelRequest(GetResponseEvent $event) {
        $response = $event->getResponse();
        $request = $event->getRequest();
        $this->response = $response;
        $this->request = $request;
    }

    public function __construct(EntityManager $entityManager, Container $container) {

        $this->em = $entityManager;
        $this->container = $container;
    }

    public function getAssociatedPriceOfCurrency($prices, $currency = null) {

        $currency = $this->getCurrencyIfNotDefined($currency);

        $return_price = null;

        foreach ($prices as $price) {
            if ($price->getCurrency()->getCode() == $currency) {
                $return_price = $price;
            }
        }
        return $return_price;
    }

    public function getCurrencyIfNotDefined($currency) {
        if ($currency == null) {
            return $this->getCurrency();
        }
        return $currency;
    }

    public function getCurrency() {
        return $this->container->get('shop_core.currency')->getCurrency();
    }
    
    
    public function getFormattedPrice(Currencies $currency, $price) {
        switch ($currency->getFormat()) {
            case 1 : return $currency->getPrefix() . " " . $price;
            case 2 : return $price . " " . $currency->getPrefix();
            default : return $currency->getPrefix() . " " . $price;
        }
    }

}
