<?php

// src/Shop/CoreBundle/Services/Currency.php

namespace Shop\CoreBundle\Services;

use Symfony\Component\HttpFoundation\Response,
    Symfony\Component\HttpFoundation\Cookie,
    Symfony\Component\HttpKernel\Event\FilterResponseEvent,
    Symfony\Component\HttpKernel\Event\GetResponseEvent,
    Symfony\Component\DependencyInjection\Container,
    Doctrine\ORM\EntityManager;

class Currency {

    protected $container;
    protected $em;

    /**
     * Return the currency choosen
     *
     * @return string
     */
    public function onKernelRequest(GetResponseEvent $event) {
        $response = $event->getResponse();
        $request = $event->getRequest();

        $value = $request->cookies->get('currency');
        if ($value == null) {

            if ($this->container->hasParameter('currency')) {
                $value = $this->container->getParameter('currency');
            } else {
                $value = $this->container->getParameter('shop.core.currency');
            }

            $cookie = new Cookie(
                    'currency', $value, time() + 3600 * 24 * 7);
            if ($response == null) {
                $response = new Response;
                $response->headers->setCookie($cookie);
                $response->send();
            } else {
                $response->headers->setCookie($cookie);
            }
        }
    }

    public function getCurrency() {
        return $this->container->get('request')->cookies->get('currency');
    }

    public function getCurrencyObject() {
        return $this
                        ->em
                        ->getRepository('ShopCoreBundle:Currencies')
                        ->findOneByCode($this->getCurrency());
    }

    public function getAssociatedCurrency($currency_name) {
        if ($this->container == null) {
            return null;
        }
        if (!$this->isCurrencyExist($currency_name)) {
            return null;
        }

        return $this
                        ->em
                        ->getRepository('ShopCoreBundle:Currencies')
                        ->findOneByCode($currency_name);
    }

    public function setCurrency($response, $currency) {
        if (!$this->isCurrencyExist($currency)) {
            return;
        }
        $cookie = new Cookie(
                'currency', $currency, time() + 3600 * 24 * 7);

        $response->headers->setCookie($cookie);

        return $response;
    }

    public function isCurrencyExist($currency) {

        if ($this->container->hasParameter('availableCurrency')) {
            if (!in_array($currency, $this->container->getParameter('availableCurrency'))) {
                return false;
            }
        } else {
            if (!in_array($currency, $this->container->getParameter('shop.core.availableCurrency'))) {
                return false;
            }
        }
        return true;
    }

    public function __construct(EntityManager $entityManager, Container $container) {
        $this->em = $entityManager;
        $this->container = $container;
    }

}
