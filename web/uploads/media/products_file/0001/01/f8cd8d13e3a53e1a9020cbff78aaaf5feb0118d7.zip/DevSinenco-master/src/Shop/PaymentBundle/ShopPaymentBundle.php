<?php

namespace Shop\PaymentBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ShopPaymentBundle extends Bundle {
    
}
